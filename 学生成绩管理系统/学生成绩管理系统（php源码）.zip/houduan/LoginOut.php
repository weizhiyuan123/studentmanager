<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript">
   x=window.confirm("您确定要退出吗？");
   if(x==true) window.top.location.href="Login.php";
</script>