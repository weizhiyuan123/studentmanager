<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>个人信息查询</title>
<link href="../styles/com.css" rel="stylesheet" />
<style type="text/css">
#table2 {
	width: 50%;
	margin: 0 auto;
}
</style>
<script src="../scripts/Com.js"></script>
</head>
<body>
<div style="Display:none">
<?php 
	include "../Fun.php";      //选择数据库
	include "../IsLogin.php";  //判断用户是否登录
	$id=$_SESSION["userid"];	//登陆成功则把用户类别及用户名写入SESSION					
	$result=mysqli_query($con,"select * from teacher where teacherid='$id'");
    $row=mysqli_fetch_array($result);  //数组的键名可以是整数和字段名。
?>
</div>

    <table width="600" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><script>
	var links = new Array();
	links[1] = "";
	links[2] = "";
	links[3] = "";
	links[4] = "";
	var imgs = new Array();
	for(var n = 1; n <= 5; n++) imgs[n] = new Image();
	imgs[1].src = "../images/dianpu6.jpg";
	imgs[2].src = "../images/dianpu7.jpg";
	imgs[3].src = "../images/dianpu8.jpg";
	imgs[4].src = "../images/dianpu9.jpg";
	var tits = new Array();
	tits[1] ="百度统计";
	tits[2] = "联盟杯摄影师大赛";
	tits[3] = "百度行业报告";
	tits[4] = "联盟志";
	tits[4] = "wei";
	var imgwidth = 1100;//图片宽度
	var imgheight = 100;//图片宽度
	var str = "<style type='text/css'>";
	str += "#imgnv{display:none;position:absolute;bottom:-1px;right:0;height:16px;}#imgnv div{float:left;margin-right:1px;}";
	str += "#imgnv div.on,#imgnv div.off{margin-bottom:1px;width:30px;height:15px;line-height:18px!important;line-height:15px;font-size:9px;text-align:center;cursor:pointer;cursor:hand}";
	str += "#imgnv div.on{background:#CE0609;color:#FFF;font-weight:bold}";
	str += "#imgnv div.off{background:#323232;color:#FFF;text-decoration:none}";
	str += "#titnv{margin-top:3px;color:#000;text-align:center;display:none;}";
	str += "</style>";
	str += "<div style='position:relative'>";
	str += "<div><a id='dlink' href='" + links[1] + "' target='_blank'><img id='dimg' src='" + imgs[1].src + "' border='0' width='" + imgwidth + "' height='"+imgheight+"' style='filter:Alpha(opacity=100)' onmouseover='Pause(true)' onmouseout='Pause(false)'></a></div>";
	//修改点1：循环添加内层div内容以增加个数
	str += "<div id='imgnv'><div id='it1' class='on' onmouseover='ImgSwitch(1, true)' onmouseout='Pause(false)'>1</div><div id='it2' class='off' onmouseover='ImgSwitch(2, true)' onmouseout='Pause(false)'>2</div><div id='it3' class='on' onmouseover='ImgSwitch(3, true)' onmouseout='Pause(false)'>3</div><div id='it4' class='off' onmouseover='ImgSwitch(4, true)' onmouseout='Pause(false)'>4</div></div>";
	str += "<div id='titnv'><b>" + tits[1] + "</b></div>";
	str += "</div>";
	document.write(str);
	var oi = document.getElementById("dimg");
	var pause = false;
	var curid = 1;
	var lastid = 1;
	var sw = 1;
	var opacity = 100;
	var speed = 15;
	var delay = (document.all)? 400:700;
	function SetAlpha(){
	if(document.all){
	if(oi.filters && oi.filters.Alpha) oi.filters.Alpha.opacity = opacity;
	}else{
	oi.style.MozOpacity = ((opacity >= 100)? 99:opacity) / 100;
	}
	}
	function ImgSwitch(id, p){
	if(p){
	pause = true;
	opacity = 100;
	SetAlpha();
	}
	oi.src = imgs[id].src;
	document.getElementById("dlink").href = links[id];
	document.getElementById("it" + lastid).className = "off";
	document.getElementById("it" + id).className = "on";
	document.getElementById("titnv").innerHTML = "<b>" + tits[id] + "</b>";
	curid = lastid = id;
	}
	function ScrollImg(){
	if(pause && opacity >= 100) return;
	if(sw == 0){
	opacity += 2;
	if(opacity > delay){ opacity = 100; sw = 1; }
	}
	if(sw == 1){
	opacity -= 3;
	if(opacity < 10){ opacity = 10; sw = 3; }
	}
	SetAlpha();
	if(sw != 3) return;
	sw = 0;
	curid++;
	//修改点2：这里的4也是个数
	if(curid > 4) curid = 1;
	ImgSwitch(curid, false);
	}
	function Pause(s){
	pause = s;
	}
	function StartScroll(){
	setInterval(ScrollImg, speed);
	}
	function CheckLoad(){
	if (imgs[1].complete == true && imgs[2].complete == true) {
	clearInterval(checkid);
	setTimeout(StartScroll, 2000);
	}
	}
	var checkid = setInterval(CheckLoad, 10);
                      </script></td>
      </tr>
    </table>
    <table border="1" cellpadding="4" cellspacing="0" width="500px" id="table2" bordercolor="#328EBE">
      <tr>
        <td colspan="2" align="center" bgcolor="#FEADD6" style="font-family:'华文新魏'; font-size:20px"> 个人信息查询</td>
      </tr>
      <tr>
        <td width="35%" align="right">工 号：</td>
        <td><?php echo @$row['teacherid'];?></td>
      </tr>
      <tr>
        <td width="35%" align="right">姓 名：</td>
        <td><?php echo @$row['teachername'];?></td>
      </tr>
      <tr>
        <td width="35%" align="right">职 称：</td>
        <td><?php echo @$row['level'];?></td>
      </tr>
      <tr>
        <td width="35%" align="right">手 机：</td>
        <td><?php echo @$row['tel'];?></td>
      </tr>
      <tr>
        <td colspan="2" align="center" bgcolor="#FEADD6">&nbsp;</td>
      </tr>
</table>
</body>
</html>
