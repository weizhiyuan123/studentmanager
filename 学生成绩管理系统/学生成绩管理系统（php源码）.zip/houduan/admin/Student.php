<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../styles/com.css" rel="stylesheet" />
<style type="text/css">
table {
	width: 80%;
	margin: 0 auto;
}
</style>
<script src="../scripts/Com.js"></script>
<title>学生信息</title>
<div style='Display:none'>
<?php
  include "../Fun.php";
  include "../IsLogin.php";
?>
</div>
</head>
<body>

<script type="text/javascript">

function change()
{   
    var bms=document.form1.major.value;
	if (bms=="") {window.alert("专业名不能为空");document.form1.major.focus();}
    var bm=bms.split("|"); 
    for(i=0;i<(bm.length-1)/2;i++)    
    { with(document.form1.class1) 
         {  length = (bm.length-1)/2+1;
	        options[i+1].value = bm[2*i]; 	
		    options[i+1].text =bm[2*i+1]; 
	      }   
      }
   
}  
function checkclass()
{
	if (document.form1.class1.value=="")
	{
	   alert("请选择专业班！");
      document.form1.class1.focus();
      return false;
    }
}
</script>
<form method="post" name="form1">
<div align="center">

<font style="font-family:'华文新魏'; font-size:20px"  >学生学籍管理</font><br />

    <select name="major" id="major" onChange="change()" >
      <option value="" >请选择专业</option>
      <?php 
$sqlx="select distinct majorname from class";
$rs1=mysqli_query($con,$sqlx);
$row1=mysqli_fetch_assoc($rs1);
while($row1)
{   $zy=$row1["majorname"];
    $sqlx="select distinct classid,enrollyear,classname from class where majorname='$zy'";
	$rs2=mysqli_query($con,$sqlx);
	$row2=mysqli_fetch_assoc($rs2); 
	$class="";
	while($row2)
	{  $class.=$row2["classid"]."|".$row2["enrollyear"]."-".$row2["classname"]."|";
	   $row2=mysqli_fetch_assoc($rs2); 
	}
?>
      <option value="<?php echo $class;?>"><?php echo $row1["majorname"];?></option>
      <?php	
    $row1=mysqli_fetch_assoc($rs1);
}
?>
    </select>
    <select name="class1" id="class1">
      <option value="" >请选择班级</option>
    </select>
    &nbsp;
    <input name="search" type="submit" value="查询" onclick="return checkclass()"/>
    <br /> 
	<?php 
        if(isset($_REQUEST["search"])|| isset($_REQUEST["page"]))
        {  if(isset($_REQUEST["search"])) $_SESSION["classid"]=$_REQUEST["class1"];   
		   $sqlx="select * from class where classid='".$_SESSION["classid"]."'";
		   $rs3=mysqli_query($con,$sqlx);
	       $row3=mysqli_fetch_assoc($rs3);
		   echo $row3["enrollyear"].$row3["majorname"].$row3["classname"]."学生名单";    
    	}
    ?>
  <table>
    <thead>
		<tr>
			<th width="12%">学号</th>
			<th width="12%">姓名</th>
			<th width="12%">性别</th>
			<th width="20%">出生日期</th>
			<th width="20%">班级序号</th>
          <th width="12%">总学分</th>
			<th width="12%">删除<input type='checkbox' id='CBox' onClick='checkall(this.form)'/></th>
			
      </tr>
    </thead>
<?php 
if(isset($_REQUEST["del"]))
{
	$id=@$_REQUEST["T_id"];   
	if(!$id) echo "<script>alert('请至少选择一条记录！');</script>";			
	else{
			$num=count($id);							 
			for($i=0;$i<$num;$i++)						
			{  $delsql="delete from student where studentid='$id[$i]'";
			   mysqli_query($con,$delsql);        
			   // 在删除学号为A的学生时，将同时删除[成绩表]中学号为A的记录。
			   $delsql="delete from score where studentid='$id[$i]'";
			   mysqli_query($con,$delsql);           
			}
			echo "<script>alert('删除成功！');</script>";
		} 
	$sql="select * from student where classid='".$_SESSION["classid"]."'";
    if (!isset($_REQUEST["page"])) loadinfo($con,$sql); 
}

 if(isset($_REQUEST["search"])|| isset($_REQUEST["page"]))
 {  
    $sql="select * from student where classid='".$_SESSION["classid"]."'";
    loadinfo($con,$sql); 
 }

function loadinfo($con,$sqlstr)
{
	$result=mysqli_query($con,$sqlstr);
	$total=mysqli_num_rows($result);
	if (isset($_REQUEST["search"])) $page=1;     
	else $page=isset($_REQUEST['page'])?intval($_REQUEST['page']):1;	
	
	$num=15;                                     
	$url='Student.php';							 
	//页码计算
	$pagenum=ceil($total/$num);				      
	$prepg=$page-1;								  
	$nextpg=($page==$pagenum? 0: $page+1);		  
	
	$new_sql=$sqlstr." limit ".($page-1)*$num.",".$num;	
	$new_result=mysqli_query($con,$new_sql);
	if($new_row=@mysqli_fetch_array($new_result))
	{   
			
		do
		{
			list($id,$name,$pwd,$sex,$birthday,$classid,$credit)=$new_row;	//数组的键名为从0开始的连续整数。
			echo "<tr>";
			echo "<td width='12%'><a href='Student_update.php?id=$id'>$id</a></td>";			
			echo "<td width='12%'>$name</td>";
			echo "<td width='12%'>$sex</td>"; 		
			echo "<td width='20%' >$birthday</td>";		
			echo "<td width='20%' >$classid</td>";		
			echo "<td width='12%'>$credit</td>";				
			echo "<td width='12%'><input type='checkbox' name='T_id[]' value='$id' /></td>";
			echo "</tr>";  
		}while($new_row=mysqli_fetch_array($new_result));
			
		 $pagenav="";
		if($prepg) 
			$pagenav.="<a href='$url?page=$prepg'>上一页</a> "; 
		for($i=1;$i<=$pagenum;$i++)
		{
			if($page==$i)$pagenav.="<b><font color='#FF0000'>$i</font></b>&nbsp;";
			else $pagenav.=" <a href='$url?page=$i'>$i"."&nbsp;</a>"; 
		}
		if($nextpg)
			$pagenav.=" <a href='$url?page=$nextpg'>下一页</a>"; 
		$pagenav.="&nbsp;&nbsp;共".$pagenum."页";
		
		echo "<tr> <td colspan='7' align='center'>".$pagenav."</td></tr>";	 
	}
	else echo "<tr> <td colspan='7'  align='center'>暂无记录</td></tr>";		
}


if(isset($_REQUEST["add"]))
{
	header("Location:Student_add.php");
}


?>
        <tr> 
			<td colspan='7' align='center'><input type='submit' name='add'  value='添加' />&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='del'  value='删除' onClick="delcfm()"  />	</td>
		</tr>	
</table>
</div>
</form>
</body>
</html>