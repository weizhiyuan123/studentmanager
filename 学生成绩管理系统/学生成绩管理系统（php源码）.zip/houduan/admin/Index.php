<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body leftmargin="2" topmargin="2" marginwidth="2" marginheight="2" >
    <table width="103%"  border="0" cellpadding="0" cellspacing="0" bordercolor="#FEADD6">
          <tr>
            <td width="834" align="center" valign="middle">
    <script>
        var links = new Array();
        links[1] = "";
        links[2] = "";
        links[3] = "";
        links[4] = "";
        var imgs = new Array();
        for(var n = 1; n <= 5; n++) imgs[n] = new Image();
        imgs[1].src = "../images/dianpu6.jpg";
        imgs[2].src = "../images/dianpu7.jpg";
        imgs[3].src = "../images/dianpu8.jpg";
        imgs[4].src = "../images/dianpu9.jpg";
        var tits = new Array();
        tits[1] ="百度统计";
        tits[2] = "联盟杯摄影师大赛";
        tits[3] = "百度行业报告";
        tits[4] = "联盟志";
        tits[4] = "wei";
        var imgwidth = 1100;//图片宽度
        var imgheight = 100;//图片宽度
        var str = "<style type='text/css'>";
        str += "#imgnv{display:none;position:absolute;bottom:-1px;right:0;height:16px;}#imgnv div{float:left;margin-right:1px;}";
        str += "#imgnv div.on,#imgnv div.off{margin-bottom:1px;width:30px;height:15px;line-height:18px!important;line-height:15px;font-size:9px;text-align:center;cursor:pointer;cursor:hand}";
        str += "#imgnv div.on{background:#CE0609;color:#FFF;font-weight:bold}";
        str += "#imgnv div.off{background:#323232;color:#FFF;text-decoration:none}";
        str += "#titnv{margin-top:3px;color:#000;text-align:center;display:none;}";
        str += "</style>";
        str += "<div style='position:relative'>";
        str += "<div><a id='dlink' href='" + links[1] + "' target='_blank'><img id='dimg' src='" + imgs[1].src + "' border='0' width='" + imgwidth + "' height='"+imgheight+"' style='filter:Alpha(opacity=100)' onmouseover='Pause(true)' onmouseout='Pause(false)'></a></div>";
        //修改点1：循环添加内层div内容以增加个数
        str += "<div id='imgnv'><div id='it1' class='on' onmouseover='ImgSwitch(1, true)' onmouseout='Pause(false)'>1</div><div id='it2' class='off' onmouseover='ImgSwitch(2, true)' onmouseout='Pause(false)'>2</div><div id='it3' class='on' onmouseover='ImgSwitch(3, true)' onmouseout='Pause(false)'>3</div><div id='it4' class='off' onmouseover='ImgSwitch(4, true)' onmouseout='Pause(false)'>4</div></div>";
        str += "<div id='titnv'><b>" + tits[1] + "</b></div>";
        str += "</div>";
        document.write(str);
        var oi = document.getElementById("dimg");
        var pause = false;
        var curid = 1;
        var lastid = 1;
        var sw = 1;
        var opacity = 100;
        var speed = 15;
        var delay = (document.all)? 400:700;
        function SetAlpha(){
        if(document.all){
        if(oi.filters && oi.filters.Alpha) oi.filters.Alpha.opacity = opacity;
        }else{
        oi.style.MozOpacity = ((opacity >= 100)? 99:opacity) / 100;
        }
        }
        function ImgSwitch(id, p){
        if(p){
        pause = true;
        opacity = 100;
        SetAlpha();
        }
        oi.src = imgs[id].src;
        document.getElementById("dlink").href = links[id];
        document.getElementById("it" + lastid).className = "off";
        document.getElementById("it" + id).className = "on";
        document.getElementById("titnv").innerHTML = "<b>" + tits[id] + "</b>";
        curid = lastid = id;
        }
        function ScrollImg(){
        if(pause && opacity >= 100) return;
        if(sw == 0){
        opacity += 2;
        if(opacity > delay){ opacity = 100; sw = 1; }
        }
        if(sw == 1){
        opacity -= 3;
        if(opacity < 10){ opacity = 10; sw = 3; }
        }
        SetAlpha();
        if(sw != 3) return;
        sw = 0;
        curid++;
        //修改点2：这里的4也是个数
        if(curid > 4) curid = 1;
        ImgSwitch(curid, false);
        }
        function Pause(s){
        pause = s;
        }
        function StartScroll(){
        setInterval(ScrollImg, speed);
        }
        function CheckLoad(){
        if (imgs[1].complete == true && imgs[2].complete == true) {
        clearInterval(checkid);
        setTimeout(StartScroll, 2000);
        }
        }
        var checkid = setInterval(CheckLoad, 10);
      </script>
      </td>
      </tr>
    </table>
<table width="73%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FEADD6">
  <tr>
    <td height="30" align="center"><font color="#FF0000" size="3">管理员必读</font></td>
  </tr>
  <tr>
    <td height="30"><span style="font-size: 10pt; text-align: left">&nbsp;1<b>. </b>【教师管理】
      
      
      对教师信息进行查、增、删、改。 </span></td>
  </tr>
  <tr>
    <td height="30"><span style="font-size: 10pt; text-align: left">&nbsp;2<b>. </b>【班级管理】
      
      
      对班级信息进行查、增、删、改。 </span></td>
  </tr>
  <tr>
    <td height="30"><span style="font-size: 10pt; text-align: left">&nbsp;3<b>. </b>【学生学籍管理】
      
      
      对各班学生的学籍进行查、增、删、改。 </span></td>
  </tr>
  <tr>
    <td height="30"><span style="font-size: 10pt; text-align: left">&nbsp;4<b>. </b>【课程设置管理】
      
      
      对各专业的课程设置表进行查、增、删、改。 </span></td>
  </tr>
  <tr>
    <td height="30"><span style="font-size: 10pt; text-align: left">&nbsp;5<b>. </b>【开课表管理】对各班级各学期的开课表进行查、增、删、改。</span></td>
  </tr>
  <tr>
    <td height="30"><span style="font-size: 10pt; text-align: left">&nbsp;6<b>. </b>【学生成绩统计】
      
      
      统计各班每位学生各课程成绩总分。 </span></td>
  </tr>
</table>
</body>
</html>
