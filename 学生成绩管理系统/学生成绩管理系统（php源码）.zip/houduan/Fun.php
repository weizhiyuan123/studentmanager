﻿<?php
    //连接数据库
    error_reporting(E_ALL ^ E_DEPRECATED);              //错误控制
    header("Content-type:text/html;charset=utf-8");     //客户端发送原始的 HTTP 报头
	
	$con=mysqli_connect('localhost','root','','stu_db');
	mysqli_query($con,"SET NAMES utf8");
	session_start();
?>